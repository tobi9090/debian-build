---------------------------------------------------------------------------
-- @author Emmanuel Lepage Vallee &lt;elv1313@gmail.com&gt;
-- @copyright 2017 Emmanuel Lepage Vallee
-- @module naughty.layout
---------------------------------------------------------------------------

return {
    legacy = require( "naughty.layout.legacy" );
    box    = require( "naughty.layout.box"    );
}
