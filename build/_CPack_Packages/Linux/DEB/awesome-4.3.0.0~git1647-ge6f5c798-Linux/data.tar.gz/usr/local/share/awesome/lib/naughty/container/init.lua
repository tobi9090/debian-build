---------------------------------------------------------------------------
-- @author Emmanuel Lepage Vallee &lt;elv1313@gmail.com&gt;
-- @copyright 2019 Emmanuel Lepage Vallee
-- @module naughty.container
---------------------------------------------------------------------------

return {
    background = require( "naughty.container.background" );
}
